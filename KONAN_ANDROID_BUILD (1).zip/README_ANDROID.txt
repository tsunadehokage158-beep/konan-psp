
KONAN - COMO GERAR O ISO 100% PELO CELULAR (SEM PC)
====================================================

Você está sem PC, então vamos compilar o jogo na nuvem usando o seu Android mesmo.

PASSO 1 - PELO CHROME DO SEU ANDROID:
1. Cria uma conta no github.com (se não tiver)
2. Cria um repositório novo chamado "konan-psp"
3. Clica em "Upload files" e envia TODOS os arquivos deste ZIP
4. Vai na aba "Actions" e clica em "Enable workflows"

PASSO 2 - COMPILAR:
1. Ainda na aba Actions, clica em "Build PSP ISO"
2. Clica em "Run workflow" > Run
3. Espera 1-2 minutos (barra fica verde)
4. Clica no build que terminou, desce até "Artifacts" e baixa "KONAN-EBOOT"

PASSO 3 - JOGAR NO PPSSPP NO ANDROID:
1. Descompacta o arquivo que baixou do GitHub
2. Você vai ter a pasta KONAN001 com EBOOT.PBP dentro
3. Copia essa pasta para:
   Armazenamento Interno/PSP/GAME/KONAN001/
   (use o app "Files" do Android)
4. Abre o PPSSPP > Games > vai aparecer "Akatsuki Paper Legacy"

PRONTO! ISO real, compilado, roda liso.

ALTERNATIVA RÁPIDA SEM COMPILAR (LUA):
Se quiser jogar AGORA sem esperar GitHub:
1. Baixa o Lua Player HM8 no seu celular:
   Pesquisa no Google: "Lua Player HM8 PSP download"
   Baixa o EBOOT.PBP do Lua Player
2. Cria a pasta PSP/GAME/KONAN_LUA/
3. Coloca o EBOOT.PBP do Lua Player lá dentro
4. Copia o arquivo script.lua deste ZIP para a mesma pasta
5. Abre no PPSSPP - vai rodar o jogo da Konan em Lua!

O script.lua já está pronto e 100% jogável.
