
#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <pspgu.h>
#include <pspgum.h>
#include <stdlib.h>
#include <math.h>
PSP_MODULE_INFO("AkatsukiPaperLegacy", 0, 1, 1);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER | THREAD_ATTR_VFPU);
#define SCREEN_W 480
#define SCREEN_H 272
typedef struct { float x,y,vx,vy; int life,chakra,anim,frame,facing,isJumping; } Player;
typedef struct { float x,y; int type,life,active; } Enemy;
static Player konan; static Enemy enemies[8]; static int score=0;
int exit_callback(int a,int b,void *c){ sceKernelExitGame(); return 0; }
int CallbackThread(SceSize a,void *b){ int cbid=sceKernelCreateCallback("Exit",exit_callback,NULL); sceKernelRegisterExitCallback(cbid); sceKernelSleepThreadCB(); return 0; }
int SetupCallbacks(void){ int thid=sceKernelCreateThread("update_thread",CallbackThread,0x11,0xFA0,0,0); if(thid>=0) sceKernelStartThread(thid,0,0); return thid; }
void initGame(){ konan.x=100; konan.y=180; konan.vx=0; konan.vy=0; konan.life=100; konan.chakra=100; konan.anim=0; konan.frame=0; konan.facing=1; konan.isJumping=0;
 for(int i=0;i<8;i++){ enemies[i].active=(i<3); enemies[i].x=300+i*70; enemies[i].y=180; enemies[i].type=i%3; enemies[i].life=30+enemies[i].type*20; } }
void updateGame(SceCtrlData *pad){
 if(pad->Buttons & PSP_CTRL_LEFT){ konan.vx=-2.5f; konan.facing=-1; } else if(pad->Buttons & PSP_CTRL_RIGHT){ konan.vx=2.5f; konan.facing=1; } else { konan.vx*=0.8f; }
 if((pad->Buttons & PSP_CTRL_CROSS) && !konan.isJumping){ konan.vy=-6.0f; konan.isJumping=1; }
 konan.vy+=0.35f; konan.x+=konan.vx; konan.y+=konan.vy;
 if(konan.y>180){ konan.y=180; konan.vy=0; konan.isJumping=0; }
 if(konan.x<0) konan.x=0; if(konan.x>SCREEN_W-32) konan.x=SCREEN_W-32;
 if(pad->Buttons & PSP_CTRL_SQUARE){ for(int i=0;i<8;i++) if(enemies[i].active){ if(fabs(konan.x-enemies[i].x)<50){ enemies[i].life-=2; if(enemies[i].life<=0){ enemies[i].active=0; score+=100; } } } }
 for(int i=0;i<8;i++) if(enemies[i].active){ if(enemies[i].x>konan.x) enemies[i].x-=0.5f+enemies[i].type*0.3f; else enemies[i].x+=0.5f+enemies[i].type*0.3f; }
 konan.frame=(konan.frame+1)%60;
}
void renderGame(){
 sceGuStart(GU_DIRECT,NULL); sceGuClearColor(0xFF1a1a2e); sceGuClear(GU_COLOR_BUFFER_BIT); sceGuFinish(); sceGuSync(0,0); sceDisplayWaitVblankStart(); sceGuSwapBuffers();
}
int main(){ SetupCallbacks(); sceGuInit(); initGame(); SceCtrlData pad; sceCtrlSetSamplingCycle(0); sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
 while(1){ sceCtrlReadBufferPositive(&pad,1); if(pad.Buttons & PSP_CTRL_SELECT) break; updateGame(&pad); renderGame(); }
 sceGuTerm(); sceKernelExitGame(); return 0;
}
