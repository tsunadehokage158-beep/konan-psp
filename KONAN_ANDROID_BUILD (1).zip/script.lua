
-- AKATSUKI: Paper Legacy - Versão Lua Player (roda no PPSSPP Android sem compilar)
-- Coloque este arquivo como script.lua dentro de PSP/GAME/KONAN_LUA/ junto com EBOOT.PBP do Lua Player HM8

white = Color.new(255,255,255)
red = Color.new(255,50,50)
blue = Color.new(80,150,255)
black = Color.new(0,0,0)
pink = Color.new(255,150,200)

konan = {x=100, y=150, vx=0, vy=0, life=100, chakra=100, facing=1, frame=0, jumping=false}
enemies = {}
score = 0
wave = 1

for i=1,3 do
  enemies[i] = {x=300+i*70, y=180, life=30, active=true, type=math.random(1,3)}
end

function update()
  pad = Controls.read()

  if Controls.check(pad, KEY_LEFT) then konan.vx = -3; konan.facing = -1
  elseif Controls.check(pad, KEY_RIGHT) then konan.vx = 3; konan.facing = 1
  else konan.vx = konan.vx * 0.8 end

  if Controls.check(pad, KEY_CROSS) and not konan.jumping then
    konan.vy = -7; konan.jumping = true
  end

  konan.vy = konan.vy + 0.4
  konan.x = konan.x + konan.vx
  konan.y = konan.y + konan.vy

  if konan.y > 180 then konan.y = 180; konan.vy = 0; konan.jumping = false end

  if Controls.check(pad, KEY_SQUARE) then
    for i,e in ipairs(enemies) do
      if e.active and math.abs(konan.x - e.x) < 50 then
        e.life = e.life - 2
        if e.life <= 0 then e.active = false; score = score + 100 end
      end
    end
  end

  for i,e in ipairs(enemies) do
    if e.active then
      if e.x > konan.x then e.x = e.x - 1 else e.x = e.x + 1 end
    end
  end

  konan.frame = konan.frame + 1
end

function draw()
  screen:clear(Color.new(26,26,46))

  -- Chão
  screen:fillRect(0, 210, 480, 62, Color.new(40,40,70))

  -- Konan (desenho simples)
  -- Corpo
  screen:fillRect(konan.x, konan.y, 20, 30, black)
  -- Manto Akatsuki
  screen:fillRect(konan.x-2, konan.y, 24, 30, red)
  -- Cabeça + flor
  screen:fillRect(konan.x+5, konan.y-10, 10, 10, Color.new(255,220,180))
  screen:fillRect(konan.x+12, konan.y-12, 6, 6, pink)

  -- Papéis voando se atacando
  if Controls.check(Controls.read(), KEY_SQUARE) then
    for i=1,5 do
      screen:fillRect(konan.x + math.random(-20,40), konan.y + math.random(-10,20), 4, 4, white)
    end
  end

  -- Inimigos
  for i,e in ipairs(enemies) do
    if e.active then
      screen:fillRect(e.x, e.y, 18, 28, blue)
      screen:print(e.x, e.y-10, e.life, white)
    end
  end

  -- HUD estilo PSP
  screen:print(10,10,"VIDA: "..konan.life, red)
  screen:print(10,25,"CHAKRA: "..konan.chakra, blue)
  screen:print(350,10,"SCORE: "..score, white)
  screen:print(10,250,"X=Pulo []=Atacar ANALOGICO=Mover", white)
end

while true do
  update()
  draw()
  screen.flip()
  screen.waitVblankStart()
end
